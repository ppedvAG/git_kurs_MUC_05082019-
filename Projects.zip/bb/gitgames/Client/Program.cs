﻿using System;

namespace ConsoleClient
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
            Console.WriteLine("Rall branch!");
            Console.WriteLine("Martin S. was here.");
            Console.WriteLine("Markus war hier.");
            Console.WriteLine("Andreas was here");
            Console.WriteLine("Comment on MyLokalBranch");
            Console.WriteLine("Martin2 is auch da");
            Console.WriteLine("After setting develop to RO");
            Console.WriteLine(new NewClass().Hello());
        }
    }
}
