public class NewClass
{
    public string Hello()
    {
        return "Hello from NewClass";
    }
}